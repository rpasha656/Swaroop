import { Component } from '@angular/core';
import './home.html';
import './home.css';
@Component({
    moduleId: module.id,
    selector: 'as-home',
    template: require('./home.html'),
    styles: [require('./home.css')]
})
export class HomeComponent {
}
