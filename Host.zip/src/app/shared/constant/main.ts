export const MAIN = {
    APP: {
        BRAND: 'Angular 2 Starter'
    }
};
