import { Observable } from 'rxjs/Observable';
import { Subject, Subscription } from 'rxjs/RX';
import { FileMetadata } from '../mocks/filemetadata.model';

export abstract class PubSubServiceContract {
    abstract publish(subject: string, value: any): void;
    abstract subscribe(subject: string, handler: (value: any) => void, error?: (error: any) => void, complete?: () => void): Subscription;
    abstract addFileMetaDate(FileMetadata: any): Observable<FileMetadata[]>;
}
