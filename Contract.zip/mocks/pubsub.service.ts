import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs/Rx';
import { PubSubServiceContract } from '../src/pubsub-service.contract';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { FileMetadata } from './filemetadata.model';

@Injectable()
export class PubSubService extends PubSubServiceContract {
    private subjects: { [index: string]: Subject<any> };
    private docpubUrl = 'filemetadata.json';  // URL to web api
    public http: Http;

    constructor() {
        super();
        this.subjects = {};
    }
    publish(subject: string, value: any) {
        let rxSubject = this.subjects[subject];
        if (!rxSubject) {
            rxSubject = this.subjects[subject] = new Subject<any>();
        }
        rxSubject.next(value);
    }
    subscribe(subject: string, handler: (value: any) => void, error?: (error: any) => void, complete?: () => void) {
        let rxSubject = this.subjects[subject];
        if (!rxSubject) {
            rxSubject = this.subjects[subject] = new Subject<any>();
        }
        return rxSubject.subscribe(handler, error, complete);
    }
    addFileMetaDate(filemetadata: Object): Observable<FileMetadata[]> {
        let filemetadataString = JSON.stringify(filemetadata); // Stringify payload
        let headers = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
        let options = new RequestOptions({ headers: headers }); // Create a request option

        return this.http.post(this.docpubUrl, filemetadata, options) // ...using post request
            .map((res: Response) => res.json()) // ...and calling .json() on the response to return data
            .catch((error: any) => Observable.throw(error.json().error || 'Server error')); //...errors if any
    }
}
