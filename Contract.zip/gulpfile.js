var gulp = require("gulp");
var ts = require("gulp-typescript");
var tsProject = ts.createProject("./tsconfig.json");
var runSequence = require('run-sequence');

const del = require("del");
const references = [
    "../ui/node_modules/microui-contracts",
    "../host/node_modules/microui-contracts",
    "../ui/dist/vendor/microui-contracts",
    "../host/dist/vendor/microui-contracts"]
gulp.task("compile", function () {
    return tsProject.src()
        .pipe(tsProject())
        .js.pipe(gulp.dest("dist"));
});

gulp.task('clean', function () {
    return del(["dist"], { force: true });
});

gulp.task('clean-references', function () {
    return del(references, { force: true });
});

gulp.task("deploy", ["clean-references"], function () {
    var directories = ["**"], stream;
    if (process.argv.indexOf('--full') < 0) {
        directories.push("!./node_modules/**");
    }
    stream = gulp.src(directories);
    for (var i = 0; i < references.length; ++i) {
        stream.pipe(gulp.dest(references[i]))
    }
    return stream;
});


/**
 * Watch for changes in TypeScript, HTML and CSS files.
 */
gulp.task('watch', function () {
    gulp.watch(["./*.ts", "./**/*.ts"], ['compile']).on('change', function (e) {
        console.log('TypeScript file ' + e.path + ' has been changed. Compiling.');
        runSequence('deploy', function () {
            console.log('deploying changes');
        })
    });
});
